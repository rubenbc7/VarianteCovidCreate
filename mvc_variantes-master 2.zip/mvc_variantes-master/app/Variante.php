<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Variante extends Model
{
    //Establecer con que table se conecta
    protected $table = "variantes";
}
