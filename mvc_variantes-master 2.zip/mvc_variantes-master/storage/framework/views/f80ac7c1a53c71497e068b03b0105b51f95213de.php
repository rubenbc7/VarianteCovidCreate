<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de variantes Covid 19</title>
</head>
<body>
    <h1>Covid19 Variant List</h1>
    <p>*Updates January 28th</p>
    <a href="<?php echo e(route('variantes.create')); ?>">Add variant</a>

    <table>
        <thread>
            <tr>
                <th>Lineage</th>
                <th>Common countries</th>
                <th>Earliest date</th>
                <th>Designated number</th>
                <th>Assigned number</th>
                <th>Description</th>
                <th>WHO name</th>
            </tr>
        </thread>
        <tbody>
        <?php $__currentLoopData = $variantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($variante->lineage); ?></td>
                <td><?php echo e($variante->common_countries); ?></td>
                <td><?php echo e($variante->earliest_date); ?></td>
                <td><?php echo e($variante->designated_number); ?></td>
                <td><?php echo e($variante->assignated_number); ?></td>
                <td><?php echo e($variante->description); ?></td>
                <td><?php echo e($variante->who_name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    


</body>
</html><?php /**PATH /Users/ulsa/Desktop/mvc_variantes-master/resources/views/variantes/index.blade.php ENDPATH**/ ?>